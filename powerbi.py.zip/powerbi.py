from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

import time
import argparse
import threading

parser = argparse.ArgumentParser(description = "powerbi robot")
parser.add_argument("-w", "--workspace", help = "especifica el app workspace", required = True)
parser.add_argument("-m", "--modules", help = "especifica los modulos", nargs = "+", required = True)
args = parser.parse_args()

modules = list(map(lambda x: x.lower(), args.modules))

# NUM_ROWS = 2

def worker(title_row):
	title_name = title_row.find_element(By.CSS_SELECTOR, "a.col.col-name").get_attribute("title").lower()

	isNeeded = title_name in modules

	wait = WebDriverWait(title_row, 10)

	while isNeeded:
		try:
			wait.until(
				EC.visibility_of_element_located((By.CSS_SELECTOR, "dataset-icon-container.col.col-status-icons spinner div.powerbi-spinner.small"))
			)
		except TimeoutException:
			# refresh_button = title_row.find_element(By.CSS_SELECTOR, "content-dataset-actions section section button.refreshNow.pbi-glyph.pbi-glyph-refresh")

			refresh_button = wait.until(
				EC.element_to_be_clickable((By.CSS_SELECTOR, "content-dataset-actions section section button.refreshNow.pbi-glyph.pbi-glyph-refresh"))
			)
			refresh_button.click()

			isNeeded = False

	print("termino")


driver = None
try:
	driver = webdriver.Chrome()

	'''
	driver.get("https://powerbi.microsoft.com/es-es/")

	wait = WebDriverWait(driver, 10)

	iniciar_sesion = wait.until(
		EC.presence_of_element_located((By.XPATH, "//ul[@class='menu-secondary']/li/a[1]"))
	)
	iniciar_sesion.click()
	'''

	driver.get("https://login.microsoftonline.com/common/oauth2/authorize?client_id=871c010f-5e61-4fb1-83ac-98610a7" \
		"e9110&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3d7ql8U6aKtJD4Yot" \
		"Uctl6u0rt-Zd8veP8hf9Q2ozjlzYOMpuz7YgQdm99bdo9rwaTbYnoOYtrp1d9jVaNmbFeF6a5LMD-eCbizHbmMAJZqjpT_6tUmYuyWqWFW8iYHg1kD3csXq8Z5ZUSDVYVUgijig&nonce" \
		"=637115286732770790.MjdkNzJjNWYtMzBkNi00MDNiLTk0MmItYzRhNTdiNmEwMGQyNjFiMzQwNDItYjZhYS00MjY4LTgzOWItM2ZhMzY5YzZjNGVl&site_id=500453&" \
		"redirect_uri=https%3a%2f%2fapp.powerbi.com%2f%3fnoSignUpCheck%3d1&post_logout_redirect_uri=https%3a%2f%2fapp.powerbi.com%2f%3fnoSignUp" \
		"Check%3d1&resource=https%3a%2f%2fanalysis.windows.net%2fpowerbi%2fapi&nux=1&msafed=0")

	wait = WebDriverWait(driver, 10)

	email = wait.until(
		EC.visibility_of_element_located((By.XPATH, "//div[@class='placeholderContainer']/input[@type='email'][@name='loginfmt']"))
	)
	email.clear()
	email.send_keys("alejandro.garcia@go-sharp.com")

	siguiente = wait.until(
		EC.element_to_be_clickable((By.XPATH, "//div[@class='inline-block']/input[@type='submit'][@value='Next']"))
	)
	siguiente.click()

	# se puede quitar
	wait.until(
		EC.invisibility_of_element(email)
	)

	passwd = wait.until(
		EC.visibility_of_element_located((By.XPATH, "//div[@class='placeholderContainer']/input[@type='password'][@name='passwd']"))
	)
	passwd.clear()
	passwd.send_keys("GShp@2018")

	sign_in = wait.until(
		EC.element_to_be_clickable((By.XPATH, "//div[@class='inline-block']/input[@type='submit'][@value='Sign in']"))
	)
	sign_in.click()

	try:
		no_stay = wait.until(
			EC.visibility_of_element_located((By.CSS_SELECTOR, "div.inline-block input#idBtn_Back"))
		)
		no_stay.click()
	except: pass

	wait.until(
		EC.visibility_of_element_located((By.CSS_SELECTOR, "section.navigationPane.navigationPaneBody nav button.workspacesPaneExpander.switcher"))
		and
		EC.element_to_be_clickable((By.CSS_SELECTOR, "section.navigationPane.navigationPaneBody nav button.workspacesPaneExpander.switcher"))
	)

	workspaces = driver.find_element(By.CSS_SELECTOR, "section.navigationPane.navigationPaneBody nav button.workspacesPaneExpander.switcher")
	workspaces.click()

	'''
	wait.until(
 		EC.visibility_of_element_located((By.CSS_SELECTOR, "div.workspaces"))
	)
	'''

	search_field = wait.until(
		EC.visibility_of_element_located((By.XPATH, "//nav-pane-workspaces/div[@class='search']/input[@placeholder='Buscar']"))
	)
	search_field.clear()
	search_field.send_keys(args.workspace)

	'''
	app_workspaces = wait.until(
		EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.workspaces ul li button"))
	)	
	'''

	app_flag = True
	intentos = 0
	while app_flag:
		try:
			app_workspaces = driver.find_elements(By.XPATH, "//div[@class='scrollable-content']/ul/li/workspace-button/button[1]")

			#print(len(app_workspaces))

			if len(app_workspaces) == 1:
				app_flag = False
		except (TimeoutException, NoSuchElementException) as t:
			time.sleep(0.5)
			intentos += 1
			if intentos > 20:
				app_flag = False
				raise t


	app = list(filter(lambda x: x.get_attribute("title").lower() == args.workspace.lower(), app_workspaces))
	if len(app) == 1:
		app[0].click()
	else:
		raise Exception("error al encontrar app")

	wait.until(
		EC.visibility_of_element_located((By.CSS_SELECTOR, "div.mat-tab-links"))
	)

	content = wait.until(
		EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.mat-tab-links a"))
	)

	if len(content) > 0:
		content[3].click()

	wait.until(
		EC.visibility_of_element_located((By.XPATH, "//div[@class='scrollable-content']/div[@role='datagrid']"))
	)

	wait.until(
		EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.row.ng-star-inserted"))
	)

	title_rows = wait.until(
		EC.presence_of_all_elements_located((By.CSS_SELECTOR, "virtual-scroll div.row.ng-star-inserted"))
	)

	module_threads = []
	for (index, thread) in enumerate(title_rows):
		module_threads.append(threading.Thread(args = (title_rows[index],), target = worker))
		module_threads[index].start()

	for thread in module_threads:
		thread.join()


	'''
	for title_row in title_rows:
		print(title_row.find_element(By.CSS_SELECTOR, "a.col.col-name").get_attribute("title"))
		WebDriverWait(title_row, 10).until(
			EC.visibility_of_element_located((By.CSS_SELECTOR, "dataset-icon-container.col.col-status-icons spinner div.powerbi-spinner.small"))
		)

	flag = True
	while flag:	
		try:
			wait.until(
				EC.presence_of_all_elements_located((By.CSS_SELECTOR, "dataset-icon-container.col.col-status-icons spinner div.powerbi-spinner.small"))
			)
		except TimeoutException:
			print("sin refresh")
			flag = False

	refresh_buttons = wait.until(
		EC.presence_of_all_elements_located((By.XPATH, "//div[@class='row ng-star-inserted']/content-dataset-actions/" \
		"content-dataset-actions/section/section/button[@class='refreshNow pbi-glyph pbi-glyph-refresh']"))
	)

	for rb in refresh_buttons:
		print(rb.get_attribute("aria-describedby").lower())

	for row_name in args.modules:
		refresh = list(filter(lambda x: row_name.lower() + "dataset" in x.get_attribute("aria-describedby").lower(), refresh_buttons))
		if len(refresh) == 0:
			print("no existe modulo: " + row_name)
		else:
			refresh[0].click()
	'''

	time.sleep(20)
finally:
	if driver:
		driver.quit()

